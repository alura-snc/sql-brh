SELECT * FROM dependente
WHERE extract(MONTH FROM data_nascimento) IN (4, 5, 6)
AND (nome LIKE '%H%' OR nome LIKE '%h%');