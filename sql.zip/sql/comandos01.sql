SELECT C.nome, D.nome, d.data_nascimento FROM colaborador C
INNER JOIN dependente D ON C.matricula = D.colaborador
WHERE d.parentesco = 'Cônjuge';