SELECT C.nome, T.numero, E.email FROM colaborador C
INNER JOIN telefone_colaborador T ON C.matricula = T.colaborador
INNER JOIN EMAIL_COLABORADOR E ON C.matricula = E.colaborador
WHERE T.tipo = 'C' OR T.tipo = 'M'
AND E.tipo = 'T'
ORDER BY C.NOME;