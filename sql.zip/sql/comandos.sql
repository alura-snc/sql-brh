INSERT INTO brh.colaborador (matricula, nome, cpf, salario, departamento, cep, logradouro, complemento_endereco)
VALUES ('F32', 'Fulano de Tal ', '000.000.000-00', '5000', 'DIR', '71111-100', 'Avenida das Castanheiras', 'Casa 1');

INSERT INTO brh.projeto (id, nome, responsavel, inicio, fim)
VALUES (5, 'BI', 'F123', to_date('2022-01-26', 'yyyy-mm-dd'), null);

INSERT INTO brh.papel (id, nome)
VALUES (8, 'Especialista de Neg�cios');

INSERT INTO brh.telefone_colaborador (colaborador, numero, tipo)
VALUES ('F32', '(61) 9 9999-9999', 'C');
INSERT INTO brh.telefone_colaborador (colaborador, numero, tipo)
VALUES ('F32', '(61) 3030-4040', 'R');

INSERT INTO brh.email_colaborador (colaborador, email, tipo)
VALUES ('F32', 'fulano@email.com', 'P');
INSERT INTO brh.email_colaborador (colaborador, email, tipo)
VALUES ('F32', 'fulano.tal@brh.com;', 'T');

INSERT INTO brh.dependente (cpf, colaborador, nome, parentesco, data_nascimento)
VALUES ('243.361.552-68', 'F32', 'Filha Beltrana de Tal', 'Filho(a)', to_date('2005-06-25', 'yyyy-mm-dd'));
INSERT INTO brh.dependente (cpf, colaborador, nome, parentesco, data_nascimento)
VALUES ('243.361.552-65', 'F32', 'Esposa Cicrana de Tal', 'Cônjuge', to_date('1994-03-30', 'yyyy-mm-dd'));