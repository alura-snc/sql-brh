SELECT nome, salario FROM colaborador
WHERE salario = (SELECT MAX(SL.salario) FROM colaborador SL);