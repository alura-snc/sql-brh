SELECT nome, matricula, salario, CASE
                                     WHEN salario BETWEEN 0 AND 3000 THEN 'J�mior'
                                     WHEN salario BETWEEN 3001 AND 6000 THEN 'Pleno'
                                     WHEN salario BETWEEN 6001 AND 20000 THEN 'S�nior'
                                     WHEN salario > 20001 THEN 'Corpo diretor'
                                     ELSE ''
                                     END
                                     AS senioridade
FROM colaborador
ORDER BY senioridade;
